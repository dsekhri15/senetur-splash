(function() {
  $.fn.serializeObject = function() {
    var i, len, o, obj, ref;
    obj = {};
    ref = this.serializeArray();
    for (i = 0, len = ref.length; i < len; i++) {
      o = ref[i];
      obj[o.name] = o.value;
    }
    return obj;
  };

}).call(this);
